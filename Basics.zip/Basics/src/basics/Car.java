package basics;

public class Car {
	
	public int topSpeed;
	
	public Car() {
		topSpeed = 200;
	}
	
	public Car(int speed) {
		this.topSpeed = speed;
	}
	
}
