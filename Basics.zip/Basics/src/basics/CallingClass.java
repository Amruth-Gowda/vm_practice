package basics;

public class CallingClass {

	public static void main(String[] args) {
		int []arr = {5, 7, 9, 16};
		int res = SumOfSquareNumber.sumOfSquareNumber(arr);
		System.out.println(res);
	}

}
